class Node:
    def __init__(self, attr:list) -> None:
        self.attr = list    #List of floats
        self.val = None     #For class: True=Yes , False=No tested for diabetes
        self.dist = None    #Store the k smallest nodes


#Heidi:

